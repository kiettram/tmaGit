package object1;

public interface Task {

	public void update (Chicken chicken);

}
